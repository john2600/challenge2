package com.southwest.training.app;


public interface IStrategyResult {
	public StrategyResult decodificar();

}

